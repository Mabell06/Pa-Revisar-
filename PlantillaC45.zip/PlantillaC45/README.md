Fin de Etapa 8. 
